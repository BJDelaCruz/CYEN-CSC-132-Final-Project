<?xml version="1.0" encoding="UTF-8"?>
<tileset name="dungeon2" tilewidth="20" tileheight="20" tilecount="625" columns="25">
 <image source="Dungeon_C.png" width="512" height="512"/>
</tileset>
