<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Inside_C" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="Inside_C.png" width="512" height="512"/>
</tileset>
