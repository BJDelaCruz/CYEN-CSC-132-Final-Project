<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Dungeon_A5" tilewidth="32" tileheight="32" tilecount="128" columns="8">
 <image source="Dungeon_A5.png" width="256" height="512"/>
</tileset>
