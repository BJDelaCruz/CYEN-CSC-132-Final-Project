<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Inside_A2" tilewidth="32" tileheight="32" tilecount="192" columns="16">
 <image source="Inside_A2.png" width="512" height="384"/>
</tileset>
